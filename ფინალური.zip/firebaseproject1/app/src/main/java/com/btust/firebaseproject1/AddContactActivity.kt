package com.btust.firebaseproject1

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.provider.ContactsContract
import android.widget.Button
import android.widget.EditText
import android.widget.RatingBar
import android.widget.Toast
import com.google.firebase.database.FirebaseDatabase
import kotlinx.android.synthetic.main.activity_add_contact.*

class AddContactActivity : AppCompatActivity() {

    lateinit var contactName: EditText
    lateinit var ratingBar: RatingBar
    lateinit var phoneNumber: EditText
    lateinit var addButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_contact)
        contactName = findViewById(R.id.contactName)
        ratingBar = findViewById(R.id.ratingBar)
        phoneNumber = findViewById(R.id.phoneNumber)
        addButton = findViewById(R.id.addButton)
        addButton.setOnClickListener {
            saveNumbers()
        }
        backBtn.setOnClickListener {
            val intent = Intent(this,MainActivity::class.java)
            startActivity(intent)
            finish()
        }
    }
    private fun saveNumbers(){
        val name = contactName.text.toString()
        val number = phoneNumber.text.toString()
        if(name.isEmpty() || number.isEmpty()){
            contactName.error = "Please fill all the forms."
            return
        }
        val ref = FirebaseDatabase.getInstance().getReference("contacts")
        val contactId = ref.push().key
        val contact = contactInfo(contactId, name, number, ratingBar.numStars)
        if (contactId != null) {
            ref.child(contactId).setValue(contact).addOnCompleteListener {
                Toast.makeText(applicationContext, "Contact saved successfully.", Toast.LENGTH_LONG).show()

                }
            }
        }
    }

